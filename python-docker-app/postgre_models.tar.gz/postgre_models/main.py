import os
from models import TestRun
from datetime import datetime
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
dbusername = os.environ['POSTGRESQL_USERNAME']
dbpass = os.environ['POSTGRESQL_PASS']
engine = create_engine('postgresql+psycopg2://{}:{}@localhost:5432/test_db'.format(dbusername, dbpass))
session = sessionmaker(bind=engine)()
session.connection().connection.set_isolation_level(1)

def create_entry():
    """
    This part is from Vm to container.
    """
    testcase = TestRun(created_at=datetime.utcnow(), status="Queued")
    session.add(testcase)
    session.commit()
    testcase.id()

def update_query(id):
    date1 = datetime.utcnow()
    query = sqlalchemy.update(TestRun).values(started_at = date1)
    query = query.where(TestRun.id == id)
    session.execute(query)
    session.commit()

def get_all_records():
    query = sqlalchemy.select([TestRun])
    return session.execute(query).fetchall()

def get_one_record(id):
    query = sqlalchemy.select([TestRun]).where(TestRun.id==id)
    ResultProxy = session.execute(query)
    return ResultProxy.fetchall()

    
if __name__ == "__main__":
    create_entry()
